## Password Variables

The following variables are automatically replaced:

- `[WPLOGIN]` - Username
- `[UPPERLOGIN]` - Username in uppercase
- `[DOMAIN]` - Domain name (first part)
- `[DDOMAIN]` - Full domain name
- `[YEAR]` - Current year
- `[UPPERALL]` - Username in uppercase
- `[LOWERALL]` - Username in lowercase
- `[UPPERONE]` - Username capitalized
- `[LOWERONE]` - First char lowercase, rest uppercase
- `[AZDOMAIN]` - Domain with special chars removed
- `[REVERSE]` - Username reversed
- `[DVERSE]` - Domain reversed
- `[UPPERDO]` - Domain capitalized
- `[UPPERDOMAIN]` - Domain in uppercase